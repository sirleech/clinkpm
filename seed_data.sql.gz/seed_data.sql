-- phpMyAdmin SQL Dump
-- version 3.3.2deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 09, 2011 at 10:59 AM
-- Server version: 5.1.41
-- PHP Version: 5.3.2-1ubuntu4.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `clinkpm`
--

-- --------------------------------------------------------

--
-- Table structure for table `deliverables`
--

CREATE TABLE IF NOT EXISTS `deliverables` (
  `deliverable_id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(6) DEFAULT NULL,
  `release_task_id` mediumint(9) NOT NULL,
  `type` varchar(10) NOT NULL COMMENT '[project,amp]',
  `production_fix` tinyint(1) NOT NULL,
  PRIMARY KEY (`deliverable_id`),
  KEY `user_id` (`user_name`,`release_task_id`),
  KEY `release_task_id` (`release_task_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `deliverables`
--


-- --------------------------------------------------------

--
-- Table structure for table `leave_plans`
--

CREATE TABLE IF NOT EXISTS `leave_plans` (
  `leave_id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(6) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `leave_type` varchar(10) NOT NULL,
  `estimate` tinyint(1) NOT NULL,
  PRIMARY KEY (`leave_id`),
  KEY `user_name` (`user_name`),
  KEY `leave_type` (`leave_type`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=65 ;

--
-- Dumping data for table `leave_plans`
--

INSERT INTO `leave_plans` (`leave_id`, `user_name`, `start_date`, `end_date`, `leave_type`, `estimate`) VALUES
(64, 'chris', '2011-01-01', '2011-04-01', 'rec', 0);

-- --------------------------------------------------------

--
-- Table structure for table `leave_types`
--

CREATE TABLE IF NOT EXISTS `leave_types` (
  `leave_type` varchar(10) NOT NULL,
  PRIMARY KEY (`leave_type`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `leave_types`
--

INSERT INTO `leave_types` (`leave_type`) VALUES
('maternity'),
('rec'),
('training');

-- --------------------------------------------------------

--
-- Table structure for table `public_holidays`
--

CREATE TABLE IF NOT EXISTS `public_holidays` (
  `public_holiday_id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `description` varchar(255) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`public_holiday_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `public_holidays`
--

INSERT INTO `public_holidays` (`public_holiday_id`, `description`, `date`) VALUES
(1, 'New Years Day', '2011-01-04'),
(2, 'Australia Day', '2011-01-26'),
(3, 'Canberra Day', '2011-03-14'),
(4, 'Good Friday', '2011-04-22'),
(5, 'Easter Monday', '2011-04-25'),
(6, 'Anzac Day', '2011-04-25'),
(7, 'Congruence Of Easter Monday and Anzac Day', '2011-04-26'),
(8, 'Queen''s Birthday', '2011-06-16'),
(9, 'Labour Day', '2011-10-03'),
(10, 'Family and Community Day', '2011-10-10'),
(11, 'Christmas Day', '2011-12-26'),
(12, 'Boxing Day', '2011-12-27');

-- --------------------------------------------------------

--
-- Table structure for table `releases`
--

CREATE TABLE IF NOT EXISTS `releases` (
  `release_id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `letter` char(1) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `release_type` varchar(15) NOT NULL,
  PRIMARY KEY (`release_id`),
  KEY `release_type` (`release_type`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `releases`
--

INSERT INTO `releases` (`release_id`, `letter`, `start_date`, `end_date`, `release_type`) VALUES
(3, 'f', '2010-12-05', '2011-03-05', 'major'),
(4, '6', '2011-03-06', '2011-06-18', 'major');

-- --------------------------------------------------------

--
-- Table structure for table `release_tasks`
--

CREATE TABLE IF NOT EXISTS `release_tasks` (
  `release_task_id` mediumint(9) NOT NULL AUTO_INCREMENT,
  `task_id` mediumint(9) NOT NULL,
  `release_id` mediumint(9) NOT NULL,
  `team` varchar(3) NOT NULL,
  `release_task_type` varchar(10) NOT NULL COMMENT '[project,amp]',
  PRIMARY KEY (`release_task_id`),
  KEY `task_id` (`task_id`,`release_id`),
  KEY `release_id` (`release_id`),
  KEY `team` (`team`),
  KEY `release_task_type` (`release_task_type`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `release_tasks`
--

INSERT INTO `release_tasks` (`release_task_id`, `task_id`, `release_id`, `team`, `release_task_type`) VALUES
(1, 24044, 3, 'fc1', 'project'),
(3, 39926, 4, 'fc1', 'project'),
(4, 39790, 4, 'fc1', 'project'),
(5, 41404, 4, 'fc1', 'project'),
(6, 31201, 4, 'fc1', 'amp'),
(7, 31293, 4, 'fc1', 'amp'),
(8, 31307, 4, 'fc1', 'amp'),
(9, 31329, 4, 'fc1', 'amp'),
(10, 39690, 4, 'fc3', 'project');

-- --------------------------------------------------------

--
-- Table structure for table `release_task_type`
--

CREATE TABLE IF NOT EXISTS `release_task_type` (
  `release_task_type` varchar(10) NOT NULL,
  PRIMARY KEY (`release_task_type`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `release_task_type`
--

INSERT INTO `release_task_type` (`release_task_type`) VALUES
('amp'),
('project');

-- --------------------------------------------------------

--
-- Table structure for table `release_types`
--

CREATE TABLE IF NOT EXISTS `release_types` (
  `release_type` varchar(20) NOT NULL,
  PRIMARY KEY (`release_type`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `release_types`
--

INSERT INTO `release_types` (`release_type`) VALUES
('emergency'),
('major'),
('weekly');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE IF NOT EXISTS `roles` (
  `roles` varchar(10) NOT NULL,
  PRIMARY KEY (`roles`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`roles`) VALUES
('ba'),
('designer'),
('other'),
('teamleader'),
('techo');

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

CREATE TABLE IF NOT EXISTS `tasks` (
  `task_id` mediumint(9) NOT NULL,
  `description` varchar(255) NOT NULL,
  PRIMARY KEY (`task_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tasks`
--

INSERT INTO `tasks` (`task_id`, `description`) VALUES
(24044, 'Paid Parental Leave (PPL)'),
(31201, 'Production Fixes'),
(31293, 'CPI BBY'),
(31307, 'NFYA'),
(31329, 'FAO Reconciliation FTB Including ATO Interagency Testing'),
(39690, 'FTB Advances (Election Commitment)'),
(39790, 'Better Access to Family Payment Baby Bonus Advance (Election Commitment)'),
(39926, 'Healthy Start For Kids (Election Commitment)'),
(41404, '16 to 18 Year Olds (Election Commitment)'),
(66555, 'Triplet Bonus');

-- --------------------------------------------------------

--
-- Table structure for table `teams`
--

CREATE TABLE IF NOT EXISTS `teams` (
  `team` varchar(3) NOT NULL,
  PRIMARY KEY (`team`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teams`
--

INSERT INTO `teams` (`team`) VALUES
('fc1'),
('fc3'),
('fc4'),
('mgt');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `user_name` varchar(6) NOT NULL,
  `password` varchar(30) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `sur_name` varchar(30) NOT NULL,
  `team` varchar(3) NOT NULL,
  `role` varchar(10) NOT NULL,
  `email_address` varchar(255) NOT NULL,
  `phone_number` varchar(8) NOT NULL,
  `area_code` varchar(2) NOT NULL,
  PRIMARY KEY (`user_name`),
  KEY `team` (`team`),
  KEY `role` (`role`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_name`, `password`, `first_name`, `sur_name`, `team`, `role`, `email_address`, `phone_number`, `area_code`) VALUES
('admin', 'admin', 'Administrator', '', 'mgt', 'other', '', '', ''),
('chris', '', 'chris', 'lee', 'fc1', 'techo', '', '', '');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `deliverables`
--
ALTER TABLE `deliverables`
  ADD CONSTRAINT `deliverables_ibfk_1` FOREIGN KEY (`release_task_id`) REFERENCES `release_tasks` (`release_task_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `deliverables_ibfk_2` FOREIGN KEY (`user_name`) REFERENCES `users` (`user_name`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_2` FOREIGN KEY (`role`) REFERENCES `roles` (`roles`) ON UPDATE CASCADE,
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`team`) REFERENCES `teams` (`team`) ON UPDATE CASCADE;
